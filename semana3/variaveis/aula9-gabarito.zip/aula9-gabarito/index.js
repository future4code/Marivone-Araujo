// Exercícios de interpretação de código //

/*
1. É impresso o seguinte no console:
10
10 5

2. É impresso o seguinte no console:
10
10
10

*/

// Exercícios de escrita de código //

/*
1.

let nome
let idade
console.log(typeof nome, typeof idade)
// Imprime undefined, pois não foi definido nenhum valor para essas variáveis

nome = prompt("Qual o seu nome?")
idade = prompt("Qual a sua idade?")

console.log(typeof nome, typeof idade)
// As duas variáveis são do tipo string, pois o prompt sempre retorna uma string, mesmo se o usuário escrever um número

console.log("Olá ", nome, " você tem ", idade, " anos")


2.

let nome = prompt("Qual o seu nome?")
console.log(nome)

let idade = prompt("Qual a sua idade?")
console.log(idade)

let filme = prompt("Qual o seu filme favorito?")
console.log(filme)

let doce = prompt("Qual o seu doce favorito?")
console.log(doce)

let salgado = prompt("Qual o seu salgado favorito?")
console.log(salgado)


3. 

let comidas = ["Lasanha", "Pizza", "Brigadeiro", "Hamburguer", "Alface"]

console.log(comidas)

console.log("Essas são minhas comidas favoritas:")

console.log(comidas[0])
console.log(comidas[1])
console.log(comidas[2])
console.log(comidas[3])
console.log(comidas[4])

let comidaFavorita = prompt("Qual a sua comida favorita?")
comidas[1] = comidaFavorita

console.log(comidas)


4.

let perguntas = ["Você está usando uma roupa azul hoje?", "Você gosta de esportes?", "Você gosta de Harry Potter?"]
let respostas = [false, true, true]

console.log(perguntas[0], respostas[0])
console.log(perguntas[1], respostas[1])
console.log(perguntas[2], respostas[2])

*/